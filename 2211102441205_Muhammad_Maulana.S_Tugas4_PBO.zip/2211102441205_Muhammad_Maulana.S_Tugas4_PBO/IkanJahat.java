import greenfoot.*;   
 public class IkanJahat extends Actor  
 {  
   public int totalPoisonEat = 0;  
   public int totalFishEat = 0;  
   Score score_field = new Score("Score:" + totalFishEat);  
   public void act()   
   {  
     keyBoardControl();  
     eat();  
     checkScore();  
   }    
   public void checkScore()  
   {  
     if(totalPoisonEat >= 1)   
     {  
       setImage("fishMainDead.png");   
       GameOver alert_GameOver = new GameOver();  
       Greenfoot.setWorld(new GameOver());     
       Greenfoot.delay(350);  
         
     }  
     if(totalFishEat >= 10)   
     {  
       GameOver alert_GameOver = new GameOver();  
       Greenfoot.setWorld(new GameOver());    
       //Greenfoot.stop();  
       Greenfoot.delay(350);    
     }  
   }  
   public void keyBoardControl()  
   {   
     if (Greenfoot.isKeyDown("left") )  
     {  
       setImage("fishMain2left.png");      
       move (-3) ;  
       if (Greenfoot.isKeyDown("down"))  
         turn (-3) ;  
       if (Greenfoot.isKeyDown("up"))  
         turn (3);     
     }     
     if (Greenfoot.isKeyDown("right"))  
     {   
       setImage("fishMain2.png");  
       move (3);  
       if (Greenfoot.isKeyDown("down"))  
         turn (3) ;  
       if (Greenfoot.isKeyDown("up"))  
         turn (-3);  
     }  
   }  
   public void eat()  
   {  
     Actor Score;  
     Actor fish;  
     fish = getOneObjectAtOffset(4, 4, fish.class);  
     getWorld().addObject(score_field, 90, 30);  
     if (fish != null)  
     {  
       World Sea;  
       Sea = getWorld() ;  
       Sea.removeObject(fish);  
       Greenfoot.playSound("eating.wav");  
       totalFishEat++;  
       score_field.setText("Score: " +totalFishEat);  
        
     }  
     Actor fish1;  
     fish1 = getOneObjectAtOffset(4, 4, fish1.class);  
     if (fish1 != null)  
     {  
       World world;  
       world = getWorld() ;  
       world.removeObject(fish1);  
       Greenfoot.playSound("eating.wav");  
       totalFishEat++;  
       score_field.setText("Score: " +totalFishEat);    
     }  
     Actor fish3;  
     fish3 = getOneObjectAtOffset(4, 4, fish3.class);  
     if (fish3 != null)  
     {  
       World world;  
       world = getWorld() ;  
       world.removeObject(fish3);  
       Greenfoot.playSound("loose.mp3");  
       totalPoisonEat++;  
         
     }  
   }  
    
 }  
